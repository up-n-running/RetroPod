#include <stdio.h>

void main () {
	char *temp;
	printf("%s\n", "Press Enter To Exit");
	gets(temp);
}
